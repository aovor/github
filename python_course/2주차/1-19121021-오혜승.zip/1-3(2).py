#실습 3-2
a="길동"
print("안녕", a, end = "-")
print("반갑다", a, end = "-")
print("오랜만이야", a, "\n")

