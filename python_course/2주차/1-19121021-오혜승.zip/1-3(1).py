#실습 3-1
a="길동"
print("안녕", a)
print("반갑다", a)
print("오랜만이야",a, "\n")
