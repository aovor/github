print("사이버보안전공 19121021 오혜승")

day = int(input())
month = int(input())
name =input()

if day == 25 and month == 9 and name == "홍길동":
    print("생일 축하합니다.")
else:
    print("일치하는 정보가 없습니다.")
