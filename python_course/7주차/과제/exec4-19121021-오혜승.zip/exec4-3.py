print("사이버보안전공 19121021 오혜승")

os = input("태블릿용 운영체제는 무엇인가요? ")
if os == "안드로이드":
    print("구글")
elif os == "iOS":
    print("애플")
elif os == "윈도우":
    print("마이크로소프트")
