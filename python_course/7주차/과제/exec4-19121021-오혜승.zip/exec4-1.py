print("사이버보안전공 19121021 오혜승")

num = int(input("보퍼트 등급을 입력하시오:"))


if num == 0:
    print("고요")
elif num == 1:
    print("실바람")
elif num == 2:
    print("남실바람")
elif num == 3:
    print("산들바람")
elif num == 4:
    print("건들바람")
elif num == 5:
    print("흔들바람")
elif num == 6:
    print("된바람")
elif num == 7:
    print("센바람")
elif num == 8:
    print("큰바람")
elif num == 9:
    print("큰센바람")
elif num == 10:
    print("노대바람")
elif num == 11:
    print("왕바람")
elif num == 12:
    print("싹쓸바람")
else:
    print("부적절한 숫자")
