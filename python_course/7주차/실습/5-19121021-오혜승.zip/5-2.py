print("사이버보안전공 19121021 오혜승")

a = float(input())

if a > 0:
    print("양수")

else:
    if a < 0:
        print("음수")
    else:
        print("0")

print("----------------------------------------")

a = float(input())

if a > 0:
    print("양수")
elif a < 0:
    print("음수")
else:
    print("0")
