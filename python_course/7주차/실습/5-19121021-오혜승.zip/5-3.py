print("사이버보안전공 19121021 오혜승")

a = int(input())
b = int(input())

y = 0
if a > 10:
    y += 1
elif b > 20:
    y += 1
else:
    y -= 2

print(y)
