print("사이버보안전공 19121021 오혜승")

a = int(input())

y = 0

if a > 0:
    y += 1

b = int(input())

if not(a <= 0):
    print("안녕 철수!")

a += 1

if a > 0:
    print("안녕 영희!")

print(b)
