print("사이버보안전공 19121021 오혜승")

first_name = input("영문 이름을 입력하여라: ")
last_name = input("영문 성을 입력하여라: ")

full_name = first_name + " " + last_name
print(full_name)
