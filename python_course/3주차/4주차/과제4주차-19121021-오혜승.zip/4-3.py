print("사이버보안전공 19121021 오혜승")
month = int(input("달을 입력해 주세요: "))
day = int(input("일을 입력해 주세요: "))
total = (month-1) * 30 + day

print("1월 1일부터 경과된 총 일 수는", total, "일입니다.")
