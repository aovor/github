print("사이버보안전공 19121021 오혜승")

import math

a = int(input("A 변의 길이를 입력하세요: "))
b = int(input("B 변의 길이를 입력하세요: "))

c = a ** 2 + b ** 2
print("A와 B를 변으로 갖는 직각삼각형의 빗변 길이는", math.sqrt(c), "입니다.")
