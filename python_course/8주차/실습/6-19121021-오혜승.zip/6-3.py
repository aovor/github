print("사이버보안전공 19121021 오혜승")

x = int(input())
if x == 1:
    print("좋은 아침!")
    print("안녕하세요?")
    print("별일 없으시죠?")
elif x == 2:
    print("즐거운 저녁!")
    print("안녕하세요?")
    print("별일 없으시죠?")
elif x == 3:
    print("좋은 오후")
    print("별일 없으시죠?")
else:
    print("안녕히 주무세요")
