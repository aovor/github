print("사이버보안전공 19121021 오혜승")

for i in range(0, 7, 1) :
  for j in range(0, i, 1):
    print(j, end = ' ')
  print()
