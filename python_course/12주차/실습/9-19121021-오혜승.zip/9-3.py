print("사이버보안전공 19121021 오혜승")

i = 0
a = int(input())

while True:
    if i % 2 != 0:
        print(i)
    i += 5
    if i >= a: break
