print("사이버보안전공 19121021 오혜승")

a = [None] * 10
for i in range(0, 10, 1):
    a[i] = int(input())
    a[i] = a[i] ** 3

for i in range(0, 10, 1):
    print(a[i])
    
